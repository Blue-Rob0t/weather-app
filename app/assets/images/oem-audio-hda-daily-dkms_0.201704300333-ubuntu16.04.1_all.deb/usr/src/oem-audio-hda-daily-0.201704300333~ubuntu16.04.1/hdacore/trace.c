/*
 * tracepoint definitions for HD-audio core drivers
 */

#define CREATE_TRACE_POINTS
#include "trace.h"
